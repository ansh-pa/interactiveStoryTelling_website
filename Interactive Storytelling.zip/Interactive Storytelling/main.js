let searchIconEle = document.getElementById('searchIcon');
let searchInputEle = document.getElementById('searchInput');
let searchContainerEle = document.getElementById('searchContainer');
let searchCloseEle = document.getElementById('searchClose');
let dekstopNavEle = document.getElementById('dekstopNav');
let overlayEle = document.getElementById('overlay');
let hrEle = document.getElementById('hr');

let searchMediumBtn = document.getElementById('searchMedium');
let searchMediumEle = document.getElementById('searchMediumEle');
let closeMediumBtn = document.getElementById('closeMedium');

// Functions for showing and hiding overlay with elements
function showOverlay() {
    overlayEle.classList.add('show');
}

function hideOverlay() {
    overlayEle.classList.remove('show');
    searchContainerEle.classList.add('hide');
    searchIconEle.classList.remove('hide');
    dekstopNavEle.classList.remove('hide');
    hrEle.classList.remove('hide');
    searchMediumEle.classList.add('hide');
    searchMediumBtn.classList.remove('hide');
}

// Event listeners for search actions
searchIconEle.onclick = function(){
    searchContainerEle.classList.toggle('hide');
    searchIconEle.classList.toggle('hide');
    dekstopNavEle.classList.toggle('hide');
    showOverlay();
    hrEle.classList.toggle('hide');
}

searchCloseEle.onclick = function(){
    hideOverlay();
}

overlayEle.onclick = function(){
    hideOverlay();
}

searchMediumBtn.onclick = function(){
    searchMediumEle.classList.toggle('hide');
    showOverlay();
    searchMediumBtn.classList.toggle('hide');
}

closeMediumBtn.onclick = function(){
    hideOverlay();
}

// Hide overlay and reset state on window resize
window.addEventListener('resize', hideOverlay);


document.querySelector('.nav-for-md ul li:nth-child(2)').addEventListener('mouseenter', function () {
    document.querySelector('.dropdown-explore').classList.remove('hide');
});

document.querySelector('.nav-for-md ul li:nth-child(2)').addEventListener('mouseleave', function () {
    document.querySelector('.dropdown-explore').classList.add('hide');
});
